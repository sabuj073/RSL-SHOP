<?php $__env->startSection("content"); ?>
<main class="main">
            <nav class="breadcrumb-nav">
                <div class="container">
                    <ul class="breadcrumb">
                        <li><a href="/"><i class="d-icon-home"></i></a></li>
                        <li>FAQs</li>
                    </ul>
                </div>
            </nav>
            <div class="page-header" style="background-image: url(images/page-header/faq.jpg)">
                <h3 class="page-subtitle lh-1">Frequently</h3>
                <h1 class="page-title font-weight-bold text-capitalize lh-1">Asked Questions</h1>
            </div>
            <div class="page-content mb-10 pb-8">
                <section>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 mt-10">
                                <div class="accordion accordion-border accordion-boxed accordion-plus">
                                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card">
                                        <div class="card-header">
                                            <a href="#collapse2-1" class="<?php if($loop->first): ?> collapse <?php else: ?> expand <?php endif; ?>"><?php echo $row->question; ?></a>
                                        </div>
                                        <div id="collapse2-1" class="<?php if($loop->first): ?> expanded <?php else: ?> collapsed <?php endif; ?>">
                                            <div class="card-body">
                                                <p><div class="text-justify"><?php echo $row->answer; ?></div></p>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </main>
<?php $__env->stopSection(); ?>
<script type="text/javascript">
    document.addEventListener("DOMContentLoaded", function(event) {
        toggleCategory();
    });
</script>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tdbd/Desktop/Sabuj/shop/resources/views/faq.blade.php ENDPATH**/ ?>