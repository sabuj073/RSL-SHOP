<?php $__env->startSection("content"); ?>
<main class="main mt-lg-4">
    <div class="page-content">
        <?php if($banner): ?>
        <section class="intro-section container custom-padding-right">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 mb-4 mb-lg-0">
                    <div class="intro-slider animation-slider owl-carousel owl-theme owl-dot-inner row cols-1 gutter-no"
                    data-owl-options="{
                        'items': 1,
                        'dots': true,
                        'loop': true
                    }">
                    <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="intro-slide1 banner banner-fixed" style="background-color: #e8e8ea">
                        <figure>
                            <img src="<?php echo e($baseurl."c_scale,w_880/".$row->banner1); ?>" alt="<?php echo e($row->banner_alt); ?>" class="img-fluid" />
                        </figure>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <?php if($SingleLine): ?>
    <section class="container appear-animate">
        <div class="service-list">
            <div class="owl-carousel owl-theme owl-middle row cols-lg-4 cols-md-3 cols-sm-2 cols-2"
            data-owl-options="{
                'items': 4,
                'margin': 20,
                'dots': false,
                'autoplay': true,
                'responsive': {
                    '0': {
                        'items': 1
                    },
                    '576': {
                        'items': 2
                    },
                    '768': {
                        'items': 3
                    },
                    '992': {
                        'items': 4
                    }
                }
            }">
            <div class="icon-box text-center appear-animate" data-animation-options="{
                'name':'zoomInLeft',
                'delay': '.2s'
            }">
            <center><img src="<?php echo e($baseurl."c_scale,w_50/".$SingleLine->icon1); ?>" class="single-banner"></center>
            <div class="icon-box-content">
                <h4 class="icon-box-title"><?php echo $SingleLine->title1; ?>

                </div>
            </div>
            <div class="icon-box text-center appear-animate" data-animation-options="{
                'name':'zoomInLeft',
                'delay': '.3s'
            }">
            <center><img src="<?php echo e($baseurl."c_scale,w_50/".$SingleLine->icon2); ?>" class="single-banner"></center>
            <div class="icon-box-content">
                <h4 class="icon-box-title"><?php echo $SingleLine->title2; ?>

                </div>
            </div>
            <div class="icon-box text-center appear-animate" data-animation-options="{
                'name':'zoomInLeft',
                'delay': '.4s'
            }">
            <center><img src="<?php echo e($baseurl."c_scale,w_50/".$SingleLine->icon3); ?>" class="single-banner"></center>
            <div class="icon-box-content">
                <h4 class="icon-box-title"><?php echo $SingleLine->title3; ?>

                </div>
            </div>
            <div class="icon-box text-center appear-animate" data-animation-options="{
                'name':'zoomInLeft',
                'delay': '.5s'
            }">
            <center><img src="<?php echo e($baseurl."c_scale,w_50/".$SingleLine->icon4); ?>" class="single-banner"></center>
            <div class="icon-box-content">
                <h4 class="icon-box-title"><?php echo $SingleLine->title4; ?>

                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php echo $__env->make("layout.best_selling", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if($featured_categories): ?>
<section class="categories container mt-10">
    <h2 class="title title-line title-underline border-1 mb-4">Featured Categories</h2>
    <div class="row">
        <?php $__currentLoopData = $featured_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-2 col-md-2 mb-4 col-6">
         <a href="/categories/<?php echo e($row->cat_slug); ?>"> <div class="category category-group-image appear-animate" data-animation-options="{
            'name': 'fadeIn'
        }">
        <div class="row">
            <div class="col-md-12">
                <figure class="category-media">
                    <img class="cat-img" src="<?php echo e($baseurl."c_scale,w_74/".$row->cat_icon); ?>" alt="category" />
                </figure>
            </div>
        </div>
        <div class="category-content col-md-12">
            <center><h4 class="category-name text-center"><?php echo e($row->cat_title); ?></h4></center>
        </div>
    </div></a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</section>
<?php endif; ?>
<?php if($info_banner): ?>
<section class="container banner-group mt-10 pt-2">
    <div class="row">
        <div class="col-md-6 mb-4 appear-animate" data-animation-options="{
            'name': 'fadeInRightShorter',
            'delay': '.2s'
        }">
        <div class="banner banner-fixed banner1">
            <figure>
                <img src="<?php echo e($baseurl."c_scale,w_580/".$info_banner->banner1); ?>" width="580" height="240"
                alt="<?php echo e($info_banner->banner1_alt); ?>" />
            </figure>
        </div>
    </div>
    <div class="col-md-6 mb-4 appear-animate" data-animation-options="{
        'name': 'fadeInLeftShorter',
        'delay': '.2s'
    }">
    <div class="banner banner-fixed banner2">
        <figure>
           <img src="<?php echo e($baseurl."c_scale,w_870/".$info_banner->banner2); ?>" width="580" height="240"
           alt="<?php echo e($info_banner->banner2_alt); ?>" />
       </figure>
   </div>
</div>
</div>
</section>
<?php endif; ?>

<div class="col-md-12" id="post-data">
    <?php echo $__env->make("layout.category_slider", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make("layout.loader", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-md-12" id="post-data-mixed">
</div>


<?php if($randomgblogs): ?>
<section class="blog container mt-10 pt-3 mb-10 appear-animate">
    <h2 class="title title-underline title-line mb-4 pb-5">From our Blog</h2>
    <div class="owl-carousel owl-theme row cols-lg-4 cols-md-3 cols-sm-2 cols-1" data-owl-options="{
        'items': 4,
        'margin': 20,
        'loop': false,
        'responsive': {
            '0': {
                'items': 1
            },
            '576': {
                'items': 2
            },
            '768': {
                'items': 3
            },
            '992': {
                'items': 4
            }
        }
    }">
    <?php $__currentLoopData = $randomgblogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make("layout.blog_single", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</section>
<?php endif; ?>
<?php echo $__env->make("layout.clients", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="newsletter-popup mfp-hide" id="newsletter-popup">
    <div class="newsletter-content">
        <img src="<?php echo e($baseurl."c_scale,h_384/".$info->modal_image); ?>">
    </div>
</div>
</main>
<?php $__env->stopSection(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        trigger_slider();
        var page = 0;
        var check = true;
        loadmixed();
        $(window).scroll(function(){
            if($(window).scrollTop()+$(window).height()>=$(document).height()){
                page++;
                if(check){
                    loadmoreData(page);
                }
            }
        });
        $('html,body').bind('touchmove', function(e) { 
            if($(window).scrollTop()+$(window).height()>=$(document).height()){
                page++;
                if(check){
                    loadmoreData(page);
                }
            }
        });
    });
    function loadmixed(page){
        $.ajax({
            url:'/mixed-ajax',
            type:'get',
            beforeSend:function(){
            }
        })
        .done(function(data){
            if(data.html==""){
                $('.ajax-load').html("");
                return;
            }
            $("#post-data-mixed").append(data.html);
            trigger_slider();
        })
        .fail(function(jqXHR,ajaxOptions,throwError){
        })
    }
    function loadmoreData(page){
        $.ajax({
            url:'/category-ajax?page='+page,
            type:'get',
            beforeSend:function(){
                $(".ajax-load").show();
            }
        })
        .done(function(data){
            if(data.html==""){
                check = false;
                $('.ajax-load').html("");
                return;
            }
            $('.ajax-load').hide();
            $("#post-data").append(data.html);
            trigger_slider();
        })
        .fail(function(jqXHR,ajaxOptions,throwError){
            check = false;
        })
    }

</script>

<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tdbd/Desktop/Sabuj/shop/resources/views/welcome.blade.php ENDPATH**/ ?>