<?php if($products): ?>
<div class="product product-classic">
    <figure class="product-media">
        <a href="product-details/<?php echo e($products->product_slug); ?>">
            <img src="<?php echo e($baseurl."c_scale,w_300/".$products->product_image); ?>" alt="<?php echo e($products->product_alt); ?>" width="300"
            height="338">
        </a>
        <?php if($products->prev_price!=""): ?>
        <div class="product-label-group">
            <label class="product-label label-sale"><?php echo e(Helpers::getpercentage($products->product_price,$products->prev_price)); ?>% off</label>
        </div>
        <?php endif; ?>
    </figure>
    <div class="product-details">
        <h3 class="product-name">
            <a href="/product-details/<?php echo e($products->product_slug); ?>"><?php echo e($products->product_title); ?></a>
        </h3>
        <div class="product-price">
            <ins class="new-price"><?php echo e($currency.$products->product_price); ?></ins><?php if($products->prev_price!=""): ?><del class="old-price"><?php echo e($currency.$products->prev_price); ?></del><?php endif; ?>
        </div>
        <div class="ratings-container">
            <div class="ratings-full">
                <span class="ratings" style="width:<?php echo e($products->rating*20); ?>%"></span>
                <span class="tooltiptext tooltip-top"></span>
            </div>
        </div>
        <div class="product-action">
            <?php if($products->stock>0): ?>
            <a href="#" 
            class="btn-product btn-cart cart-add"
            data-quantity='1'
            data-id='<?php echo e($products->product_id); ?>' 
            data-label='<?php echo e($products->product_title); ?>' 
            data-price='<?php echo e($products->product_price); ?>'
            data-image='<?php echo e($baseurl."c_scale,w_300/".$products->product_image); ?>'
            data-stock ='<?php echo e($products->stock); ?>'
            data-slug = '<?php echo e("/product-details/".$products->product_slug); ?>'
            data-toggle="modal"
            data-target="#addCartModal" title="Add to cart"><i
            class="d-icon-bag"></i><span>add to
            cart</span></a>
            <?php else: ?>
            <a href="#" 
            class=""
            title="Out of stock"><span>Out Of Stock</span></a>
            <?php endif; ?>
            <a href="#" class="btn-product-icon btn-wishlist wishlist-add check-wish-<?php echo e($products->product_id); ?>"
            data-quantity='1'
            data-id='<?php echo e($products->product_id); ?>' 
            data-label='<?php echo e($products->product_title); ?>' 
            data-price='<?php echo e($products->product_price); ?>'
            data-image='<?php echo e($baseurl."c_scale,w_300/".$products->product_image); ?>'
            data-stock ='<?php echo e($products->stock); ?>'
            data-slug = '<?php echo e("/product-details/".$products->product_slug); ?>'
            title="Add to wishlist"><i class="d-icon-heart"></i></a>
            <a href="#" class="btn-product-icon btn-quickview" data-id='<?php echo e($products->product_id); ?>'  title="Quick View"><i
                class="d-icon-search"></i></a>
            </div>
        </div>
    </div>
    <?php endif; ?><?php /**PATH /Users/tdbd/Desktop/Sabuj/shop/resources/views/layout/product.blade.php ENDPATH**/ ?>