<?php $__env->startSection("content"); ?>
<?php $__env->startPush('styles_different_page'); ?>
<link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startPush("filter_css"); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/nouislider/nouislider.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush("fliter_js"); ?>
<script src="<?php echo e(asset('vendor/nouislider/nouislider.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<main class="main">
	<nav class="breadcrumb-nav">
		<div class="container">
			<ul class="breadcrumb">
				<li><a href="demo1.html"><i class="d-icon-home"></i></a></li>
				<li><?php if($cat_details): ?> <?php echo e($cat_details->sub_cat_name); ?> <?php endif; ?></li>
			</ul>
		</div>
	</nav>
	<div class="page-content pb-10 mb-3">
		<div class="container">
			<div class="row gutter-lg main-content-wrap">
				<?php echo $__env->make("layout.aside", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<div class="col-lg-9 main-content">
					<?php if($cat_details->sub_cat_img): ?>
					<div class="shop-banner-default banner mb-1">
						<img src="<?php echo e($baseurl.$cat_details->sub_cat_img); ?>"  alt="<?php echo e($cat_details->sub_cat_img); ?>" class="img-fluid">
					</div>
					<?php endif; ?>
					<?php if(count($data)>0): ?>
					<nav class="toolbox sticky-toolbox sticky-content fix-top">
						<div class="toolbox-right">
							<div class="toolbox-item toolbox-sort select-box text-dark">
								<label>Sort By :</label>
								<select name="orderby" class="form-control sort-order">
									<option value="default">Default</option>
									<option value="popularity" selected="selected">Most Popular</option>
									<option value="rating">Average rating</option>
									<option value="date">Latest</option>
									<option value="price-low">Sort forward price low</option>
									<option value="price-high">Sort forward price high</option>
									<option value="">Clear custom sort</option>
								</select>
							</div>
						</div>
						<div class="toolbox-right">
							<div class="toolbox-item toolbox-show select-box text-dark">
								<label>Show :</label>
								<select name="count" class="form-control per_page">
									<option value="12">12</option>
									<option value="24">24</option>
									<option value="36">36</option>
								</select>
							</div>
						</div>
					</nav>
					<div class="row cols-2 cols-sm-3 product-wrapper">
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="product-wrap">
							<?php echo $__env->make("layout.product", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
						<br><h5>No Product Found</h5>
						<?php endif; ?>
					</div>
					<nav class="toolbox toolbox-pagination">
						<center><ul class="pagination">
							<?php echo e($data->links()); ?>

						</ul></center>
					</nav>
				</div>
			</div>
		</div>
	</div>
</main>
<?php $__env->stopSection(); ?>
<script type="text/javascript">
	document.addEventListener("DOMContentLoaded", function(event) {
		toggleCategory();
	});
</script>
<?php echo $__env->make("layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/tdbd/Desktop/Sabuj/shop/resources/views/sub_category_product.blade.php ENDPATH**/ ?>