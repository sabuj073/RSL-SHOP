

<?php if(isset($cat_data)): ?>
<?php if(count($cat_data)>0): ?>
<?php $__currentLoopData = $cat_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(count(Helpers::getcategory_product($row->cat_slug))>0): ?>
    <section class="grey-section pt-10 pb-8">
        <div class="container pt-4 pb-4 white-bg" >
            <section class="product-wrapper pt-1">
                <h2 class="title title-underline with-link custom_border"><span><?php echo e($row->cat_title); ?></span><a href="categories/<?php echo e($row->cat_slug); ?>"
                    class="font-weight-bold">View All Products<i class="d-icon-arrow-right"></i></a></h2>
                    <div class="row">
                        <div class="col-lg-3 col-md-4 col-sm-6">
                            <div class="banner banner3 banner-fixed overlay-dark h-100">
                                <figure class="h-100">
                                    <img src="<?php echo e($baseurl."c_scale,w_283/".$row->cat_banner); ?>" class="h-100" alt="<?php echo e($row->cat_title); ?>"
                                     style="background-color: rgb(37, 36, 42);" />
                                </figure>
                                <div class="banner-content pr-2" data-animation-options="{
                                    'delay': '.3s'
                                }">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9 col-md-8  col-sm-6">
                        <div class="owl-carousel owl-theme row owl-nav-full  product-slide">
                        <?php
                        $data = Helpers::getcategory_product($row->cat_slug);
                            foreach($data as $products){
                        ?>
                        <?php echo $__env->make("layout.product", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php } ?>

                    </div>
                </div>
            </div>
        </section>
    </div>
</section>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php endif; ?><?php /**PATH /Users/tdbd/Desktop/Sabuj/shop/resources/views/layout/category_slider.blade.php ENDPATH**/ ?>