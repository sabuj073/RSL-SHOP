<section class="container product-wrapper mt-10" data-animation-options="{
   'delay': '.5s'
   }">
   <div class="tab tab-nav-center">
      <ul class="nav nav-tabs" role="tablist">
         <li class="nav-item">
            <a class="nav-link" href="#new-arrivals">New Arrivals</a>
         </li>
         <li class="nav-item">
            <a class="nav-link" href="#featured">Our Featured</a>
         </li>
      </ul>
      <div class="tab-content">
         <div class="tab-pane active" id="new-arrivals">
            <div class="owl-carousel owl-theme  product-slide row">
               <?php $__currentLoopData = $new_arrivals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo $__env->make("layout.product", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
         <div class="tab-pane" id="featured">
            <div class="owl-carousel owl-theme  product-slide row">
               <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo $__env->make("layout.product", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
         </div>
      </div>
   </div>
</section><?php /**PATH /Users/tdbd/Desktop/Sabuj/shop/resources/views/layout/mixed.blade.php ENDPATH**/ ?>