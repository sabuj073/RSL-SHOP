<div class="ajax-load text-center" style="display: none;">
     <p><img src="<?php echo e($baseurl."890-loading-animation_ustv16.gif"); ?>" style="width: 200px;"></p>
 </div><?php /**PATH /Users/tdbd/Desktop/Sabuj/shop/resources/views/layout/loader.blade.php ENDPATH**/ ?>